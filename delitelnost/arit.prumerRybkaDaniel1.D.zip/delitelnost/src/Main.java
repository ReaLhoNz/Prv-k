public class Main {
    public static void main(String[] args) {
         matika obj = new matika();

        obj.prumer();
    }
}